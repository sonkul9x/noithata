﻿=== WP Facebook Messenger ===
Contributors: ninjateam
Tags: facebook live chat, messenger, facebook, chat, support, help, customer support, facebook support, facebook support widget, facebook live chat for business, online support, live online support, facebook marketing, facebook fan box, facebook like box, facebook fan page
Requires at least: 3.0
Tested up to: 4.7.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Help your customers easy to contact with your business via Facebook Messenger.


== Description ==

Live demo: http://demo.ninjateam.org/facebook-messenger-for-wordpress/

Video Demo: https://ninjateam.org/facebook-messenger-wordpress/
[youtube https://www.youtube.com/watch?v=aRQNIANfxYY]

<h4>FEATURES</h4>

<ul>
<li>Help your clients easy contact with your business</li>
<li>Don’t miss potential clients</li>
<li>Grow your business</li>
<li>Work with WooCommerce</li>
<li>Display anywhere with shortcode</li>
<li>Get notification immediately</li>
<li>Increase your fan page like</li>
<li>Unlimited colors</li>
<li>Friendly</li>
<li>Be easy to use and customize</li>
<li>And more...</li>
</ul>

<h4>INSTALLATION</h4>

Manual installation is easy and takes fewer than one minute.

1. Download the plugin from wordpress.org, unpack it and upload the <strong>[WP Facebook Messenger]</strong> folder to your <strong>wp-content/plugins/</strong> directory.
2. Activate the plugin through the ‘Plugins‘ menu in WordPress.
3. Go to your main <strong>WordPress menu > Facebook Messenger > Settings</strong>, and configure the basic options (fan page URL, color, language, where to display, etc)

You’re done. Enjoy.


== Installation ==
Manual installation is easy and takes fewer than one minute.

1. Download the plugin from wordpress.org, unpack it and upload the <strong>[WP Facebook Messenger]</strong> folder to your <strong>wp-content/plugins/</strong> directory.
2. Activate the plugin through the ‘Plugins‘ menu in WordPress.
3. Go to your main <strong>WordPress menu > Facebook Messenger > Settings</strong>, and configure the basic options (fan page URL, color, language, where to display, etc)

You’re done. Enjoy.

== Screenshots ==
1. Facebook Messenger Demo
2. Facebook Messenger Popup
3. Facebook Messenger in WooCommerce page


== Changelog ==
= 1.0 =
- Version 1.0 Initial Release